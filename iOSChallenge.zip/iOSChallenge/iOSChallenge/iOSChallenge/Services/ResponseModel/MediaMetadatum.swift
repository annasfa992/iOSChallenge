//
//  MostPopulerMediaMetadatumResponseModel.swift
//  iOSChallenge
//
//  Created by anas elfaouri on 6/2/20.
//  Copyright © 2020 iOSChallenge. All rights reserved.
//


import Foundation
public class MediaMetadatum: Codable {
public var url: String?
public var format: Format?
public var height: Int?
public var width: Int?


}
