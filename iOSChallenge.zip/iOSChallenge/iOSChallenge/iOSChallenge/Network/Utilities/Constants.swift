//
//  Constants.swift
//  iOSChallenge
//
//  Created by anas elfaouri on 6/2/20.
//  Copyright © 2020 iOSChallenge. All rights reserved.
//

import Foundation



import Foundation
public class Constants {
    
    internal class URLConstants{
        

        




        
        
          internal static var Key =  "zWpbIASEUbtzo28ArGjy2qYSjhqr06na"
        internal static var BaseURL =  "http://api.nytimes.com/svc"
        
        
    
        
        
        
        internal static var mostpopular =  "/mostpopular/v2/viewed/1.json?api-key=\(Constants.URLConstants.Key)"
       
        
        
    }
    
    
    
}
